document.addEventListener('DOMContentLoaded', (event) => {
  // Find the gallery link and attach an event listener
  const galleryLink = document.getElementById('galleryEnable');
  galleryLink.addEventListener('click', function(e) {
      // Prevent the default action of the link
      e.preventDefault();

      // Hide the intro and show the gallery
      document.getElementById('intro').style.display = 'none';
      const gallery = document.querySelector('.galleryGrid');
        gallery.style.display = 'block';

        // Hladký posun k elementu galerie
        gallery.scrollIntoView({ behavior: 'smooth' });

        if (window.matchMedia("(max-width: 375px)").matches) {
          // Styl pro zařízení do 425px
          document.querySelectorAll('.about').forEach(el => el.style.top = '454%');
          document.querySelectorAll('.reviews').forEach(el => el.style.top = '502%');
          document.querySelectorAll('.showcase').forEach(el => el.style.top = '588%');
          document.querySelectorAll('.contact').forEach(el => el.style.top = '666%');
      }
       else if (window.matchMedia("(max-width: 425px)").matches) {
        // Styl pro zařízení do 425px
        document.querySelectorAll('.about').forEach(el => el.style.top = '430%');
        document.querySelectorAll('.reviews').forEach(el => el.style.top = '477%');
        document.querySelectorAll('.showcase').forEach(el => el.style.top = '560%');
        document.querySelectorAll('.contact').forEach(el => el.style.top = '650%');
    }
     else if (window.matchMedia("(max-width: 1024px)").matches) {
        // Styl pro zařízení do 1024px
        document.querySelectorAll('.about').forEach(el => el.style.top = '430%');
        document.querySelectorAll('.reviews').forEach(el => el.style.top = '516%');
        document.querySelectorAll('.showcase').forEach(el => el.style.top = '585%');
        document.querySelectorAll('.contact').forEach(el => el.style.top = '667%');
    } else {
        // Styl pro větší zařízení
        document.querySelectorAll('.about').forEach(el => el.style.top = '405%');
        document.querySelectorAll('.reviews').forEach(el => el.style.top = '492%');
        document.querySelectorAll('.showcase').forEach(el => el.style.top = '560%');
        document.querySelectorAll('.contact').forEach(el => el.style.top = '634%');
    }
  });

  // Find the return link and attach an event listener
  const returnLink = document.getElementById('Return');
  returnLink.addEventListener('click', function(e) {
      // Prevent the default action of the link
      e.preventDefault();

      // Show the intro and hide the gallery
      const intro = document.getElementById('intro');
        intro.style.display = 'block';
        document.querySelector('.galleryGrid').style.display = 'none';
        intro.scrollIntoView({ behavior: 'smooth' });

      // Reset the top property for specified classes
      document.querySelectorAll('.about').forEach(el => el.style.removeProperty('top'));
      document.querySelectorAll('.reviews').forEach(el => el.style.removeProperty('top'));
      document.querySelectorAll('.showcase').forEach(el => el.style.removeProperty('top'));
      document.querySelectorAll('.contact').forEach(el => el.style.removeProperty('top'));
  });
});




$(document).ready(function() {
  var enter = $('.js-section-3-enter');
  var exit = $('.js-section-3-exit');
  var sidebar = $('.js-section-3-sidebar');
  var sidebarBody = sidebar.find('.body');

  // Function to open the sidebar
  function openSidebar() {
    sidebar.css({display: 'block', opacity: 0}).animate({opacity: 1}, 400);
    sidebarBody.animate({right: '0px'}, 400);
  }

  // Function to close the sidebar
  function closeSidebar() {
    sidebar.animate({opacity: 0}, 400, function() {
      sidebar.css('display', 'none');
    });
    sidebarBody.animate({right: '-350px'}, 400);
  }

  // Event handler for the open button
  enter.on('click', function(e) {
    e.stopPropagation(); // Prevent the click from closing the sidebar
    openSidebar();
  });

  // Event handler for the close button
  exit.on('click', function(e) {
    e.stopPropagation(); // Prevent the click from closing the sidebar
    closeSidebar();
  });

  // Event handler for when the overlay is clicked
  $('.js-section-3-sidebar').on('click', function(event) {
    // Check if the click was on the 'body' or its children
    var isClickInsideBody = $(event.target).closest('.body').length > 0;

    // Close only if the click was outside the 'body'
    if (!isClickInsideBody) {
      closeSidebar();
    }
  });

  // Prevent closing the sidebar when clicking inside of it
  sidebar.on('click', function(event) {
    event.stopPropagation(); // Prevent the click inside from propagating to the document
  });
});


$(document).ready(function(){
  $('a[href^="#"]').on('click',function (e) {
    e.preventDefault();

    var target = this.hash;
    var $target = $(target);

    $('html, body').stop().animate({
        'scrollTop': $target.offset().top
    }, 900, 'swing', function () {
        window.location.hash = target;
    });
  });
});


document.addEventListener('DOMContentLoaded', function() {
  var navLinks = document.querySelectorAll('.navbar-collapse .nav-link');
  var navbarToggler = document.querySelector('.navbar-toggler');

  navLinks.forEach(function(link) {
    link.addEventListener('click', function() {
      if (!navbarToggler.classList.contains('collapsed')) {
        setTimeout(function() {
          navbarToggler.click();
        }, 150); // Zavře menu s malým zpožděním
      }
    });
  });
});
