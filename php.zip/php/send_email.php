<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Přiřadíme proměnné z $_POST hodnoty
    $name = strip_tags(trim($_POST["name"]));
    $email = filter_var(trim($_POST["e-mail"]), FILTER_SANITIZE_EMAIL);
    $phone = strip_tags(trim($_POST["phone"]));
    $message = strip_tags(trim($_POST["message"]));

    // Kontrola dat
    if (empty($name) OR empty($message) OR !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "invalid_input";
        exit;
    }
$email_content = "Name: $name\n";
$email_content .= "Email: $email\n\n";
$email_content .= "Phone: $phone\n\n";
$email_content .= "Message:\n$message\n";
// Připravíme e-mailové hlavičky
$email_headers = "From: $name <$email>";

// Odesíláme e-mail
$recipient = "ltwebsites@seznam.cz";
if (mail($recipient, "New contact from $name", $email_content, $email_headers)) {
    echo "success";
} else {
    echo "error";
}
} else {
    echo "invalid_request";
    }
    ?>